<?php
include_once (realpath('../classes/Service.php')); //ссылки
include_once (realpath('../classes/Inter.php'));
if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашел как админ
    Inter::head();
    $db = new DB;
    if(isset($_POST['push'])){  //если нажал кнопку, начинаем проверку
        $errors = []; //массив ошибок
        if(trim($_POST['service_name'])=='' && !isset($_GET['edit'])){ //если не ввели имя и нажали на кнопку редактирования
            $errors[] = "Введите услугу"; //ошибка
        }
        if(trim($_POST['service_price'])=='' && !isset($_GET['edit'])){ //если не ввели имя и нажали на кнопку редактирования
            $errors[] = "Введите цену"; //ошибка
        }
        if (isset($_GET['edit'])) {  //если в режиме редактирования
            if(empty($errors)) //пустой массив или нет
                Service::change($_GET['edit'], $_POST['service_name'], $_POST['service_price']); //изменение услуги
            else
                echo '<script>alert("'.array_shift($errors).'");</script>'; //если массив не пустой, выводим 1 ошибку
        }
        else {
            $service = new Service($_POST['service_name'], $_POST['service_price']); //создаем новую услугу
            if(empty($errors)) //пустой массив или нет
                $service->add(); //если массив не пустой добавляем новую услугу
            else
                echo '<script>alert("'.array_shift($errors).'");</script>'; //если массив не пустой, выводим 2 ошибку
        }
    }
    
    if(isset($_GET['delete'])){ //если нажали кнопку удаление
        Service::delete($_GET['delete']);
    }
    
    //вывод
    Service::displayForm();
    Service::displayTable();
    Inter::footer();
}

else{
    echo "<script>location.replace('index.php'); </script>"; //если не админ, перекидывает на главную страницу
}
?>