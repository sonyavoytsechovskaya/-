<?php
include_once (realpath('../classes/Record.php')); //ссылки
include_once (realpath('../classes/Inter.php'));
if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашел как админ
    Inter::head();
    $db = new DB;
    if(isset($_POST['push'])){  //если нажал кнопку, начинаем проверку
        $errors = []; //массив ошибок
        if(trim($_POST['master'])==''){  //если не выбрали мастера
            $errors[] = "Введите мастера"; //ошибка
        }
        if(trim($_POST['date'])==''){  //если не выбрали дату
            $errors[] = "Введите дату"; //ошибка
        }
        if(trim($_POST['client'])==''){ //если не выбрали клиента
            $errors[] = "Введите клиента"; //ошибка
        }
        if(trim($_POST['service'])==''){  //если не выбрали услугу
            $errors[] = "Введите услугу"; //ошибка
        }
        
        if (isset($_GET['edit'])) { //если в режиме редактирования
            if(empty($errors)) //пустой массив или нет
                Record::change($_GET['edit'], $_POST['master'], $_POST['client'], $_POST['service'], $_POST['date']);//изменение записи
            else
                echo '<script>alert("'.array_shift($errors).'");</script>'; //если массив не пустой, выводим 1 ошибку
        }
        
        else {
            $record = new Record($_POST['master'], $_POST['client'], $_POST['service'], $_POST['date']); //создаем новую запись
            if(empty($errors)) //пустой массив или нет
                $record->add(); //если массив пустой добавляем запись
            else
                echo '<script>alert("'.array_shift($errors).'");</script>'; //если массив не пустой, выводим 2 ошибку
        }
    }
    
    if(isset($_GET['delete'])){  //если нажали кнопку удаление
        Record::delete($_GET['delete']);
    }

//вывод
    Record::displayForm();
    Record::displayTable();
    Inter::footer();
}

else{
    echo "<script>location.replace('index.php'); </script>";//если не админ, перекидывает на главную страницу
}
?>