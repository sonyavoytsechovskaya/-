<?php
include_once (realpath('../classes/DB.php')); //ссылки
include_once (realpath('../classes/Inter.php'));
include_once (realpath('../classes/Applications.php'));
if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
Inter::head();

?>
 <h1 style="text-align: center; font-family: Palatino Linotype;font-size: 30pt;text-transform:uppercase;">Ремонт компьютеров в Санкт-Петербурге</h1>
<p>Вы вошли в систему как <?php echo $_SESSION['logged_master'];?>. 
<h1 style="color:red;margin-top:130px;text-align: center; font-family: Palatino Linotype;font-size: 30pt;text-transform:uppercase;">Добро пожаловать, администратор. <br>Вы имеете полный доступ ко всем базам </h1>
<?php
 if(isset($_GET['delete'])){
    Applications::delete($_GET['delete']); 
 }
Applications::displayTable();
Inter::footer();
}
else{
?>
<p>Вам сюда нельзя</p>
<a href="../index.php">На главную</a>
<?php
}

?>