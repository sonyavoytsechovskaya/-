<?php
include_once (realpath('../classes/Master.php')); //ссылки
include_once (realpath('../classes/Inter.php'));
if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
    Inter::head();
    $db = new DB;
    if(isset($_POST['push'])){  //если нажал кнопку, начинаем проверку
        $errors = []; //массив ошибок
        if(trim($_POST['master_name'])=='' && !isset($_GET['edit'])){ //если не ввели имя и нажали кнопку
            $errors[] = "Введите ФИО"; //ошибка 
        }
        if(trim($_POST['master_login'])=='' && !isset($_GET['edit'])){
            $errors[] = "Введите логин";
        }
        if (isset($_GET['edit'])) {  //если нажал кнопку, начинаем проверку
            if(empty($errors)) //пустой массив или нет
                Master::change($_GET['edit'], $_POST['master_name'], $_POST['master_login'], $_POST['master_password']);//изменение записи
            else
                echo '<script>alert("'.array_shift($errors).'");</script>'; //если массив не пустой, выводим 1 ошибку
        }
        else {
            $master = new Master($_POST['master_name'], $_POST['master_login'], $_POST['master_password']); //создаем нового мастера
            if(empty($errors)) //пустой массив или нет
                $master->add(); //если массив пустой добавляем мастера
            else
                echo '<script>alert("'.array_shift($errors).'");</script>'; //если массив не пустой, выводим 2 ошибку
        }
    }
    
    if(isset($_GET['delete'])){ //если нажали кнопку удаления
        Master::delete($_GET['delete']);
    }
    
    //вывод
    Master::displayForm();
    Master::displayTable();
    Inter::footer();
}

else{
    echo "<script>location.replace('index.php'); </script>";  //если не админ, перекидывает на главную страницу
}
?>