<?php 

$data = $_POST;

echo '<link href="css/login_form.css" rel="stylesheet">
<div class="login-page">
  <div class="form">
  <p>Вход в систему</p>
    <form class="login-form" action="index.php"  method="POST">
      <input type="text" placeholder="Логин" name="master_login" value="'.@$data['master_login'].'"/>
      <input type="password" placeholder="Пароль" name="master_password" value="'.@$data['master_password'].'"/>
      <button type="submit" name="do_login">Войти</button>
    </form>
  </div>
</div>';
?>