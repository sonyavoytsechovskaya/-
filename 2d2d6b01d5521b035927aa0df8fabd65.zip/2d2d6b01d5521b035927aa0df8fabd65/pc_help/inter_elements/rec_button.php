<?php 

$data = $_POST;

echo '<link href="css/rec_button.css" rel="stylesheet">
<div class="record-page">
<div class="form1">
 <form action="index.php" method="POST">
  <p>Вызови мастера прямо сейчас!</p>
    <form class="rec-button" action="index.php"  method="POST">
    <input type="number" placeholder="Номер телефона" name="number_client" value="'.@$data['number_client'].'"/>
      <input type="service" placeholder="Опишите свою проблему" name="services" value="'.@$data['services'].'"/>
    <input type="date"  name="date" />

      <button type="submit" name="do_record">Записаться</button>
    </form>
</div>
</div>';
?>