<?php

echo "<script>
onload = function ()
{
for (var lnk = document.links, j = 0; j < lnk.length; j++)
if (lnk [j].href == document.URL) lnk [j].style.cssText = 'color:red; border:1px solid #000';
}
</script>";
if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){
echo '<link href="../css/menu.css" rel="stylesheet">
    <div class="nav-scroller">
  <nav class="nav-scroller__items">
    <img src="../inter_elements/logo.png">
    <a class="nav-scroller__item" href="index.php">Главная</a>
    <a class="nav-scroller__item" href="client.php">Клиенты</a>
    <a class="nav-scroller__item" href="master.php">Мастера</a>
    <a class="nav-scroller__item" href="service.php">Услуги</a>
    <a class="nav-scroller__item" href="record.php">Запись</a>
    <a class="nav-scroller__item" href="../logout.php">Выйти</a>
  </nav>
</div>';

}

else{
    echo '<link href="css/menu.css" rel="stylesheet">
            <div class="nav-scroller">
              <nav class="nav-scroller__items">
                <img src="inter_elements/logo.png">
                <a class="nav-scroller__item" href="index.php">Главная</a>
                <a class="nav-scroller__item" href="master_page.php">Мастера</a>
                <a class="nav-scroller__item" href="service_page.php">Услуги</a>';
                if (isset($_SESSION['logged_master']))
                    echo '<a class="nav-scroller__item" href="logout.php">Выйти</a>';
                
        echo '</nav>
        </div>';
}
?>