<?php

if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){
echo '
    </div>

    <link href="../css/foot.css" rel="stylesheet">
    <div class="foot">
    <p>Информационная система "Компьютерная помощь"</p>
    <p>Все права защищены Ⓒ </p>
    </div>
    </div>
    </body>
    </html>';
}

else{
    echo '

    </div>
    <link href="css/foot.css" rel="stylesheet">
    <div class="foot">
    <p>Информационная система "Компьютерная помощь"</p>
    <p>Все права защищены Ⓒ </p>
    <p>2023</p>
    </div>
    </div>
    </body>
    </html>';
}

?>