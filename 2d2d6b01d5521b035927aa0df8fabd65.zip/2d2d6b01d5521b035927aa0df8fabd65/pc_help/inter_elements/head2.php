<?php

echo "<!DOCTYPE html><html>
        <head><title>Ремонт компьютеров</title></head>
        <body>";
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master']=='admin')
            echo "<link href='../css/head.css' rel='stylesheet'>";
        else
            echo "<link href='css/head.css' rel='stylesheet'>";
        echo "<div class='wrapper'>";
        include 'menu2.php';
        echo '<div class="content">';
        
?>