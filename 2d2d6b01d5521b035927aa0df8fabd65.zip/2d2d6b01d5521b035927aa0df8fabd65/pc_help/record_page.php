<?php
include_once (realpath('classes/Record.php'));
include_once (realpath('classes/Inter.php'));
Inter::head();
if(isset($_SESSION['logged_master'])){
    
    $db = new DB;
    if(isset($_POST['push'])){
        $errors = [];
        if(trim($_POST['master'])==''){
            $errors[] = "Введите мастера";
        }
        if(trim($_POST['date'])==''){
            $errors[] = "Введите дату";
        }
        if(trim($_POST['client'])==''){
            $errors[] = "Введите клиента";
        }
        if(trim($_POST['service'])==''){
            $errors[] = "Введите услугу";
        }
        
        if (isset($_GET['edit'])) {
            if(empty($errors))
                Record::change($_GET['edit'], $_POST['master'], $_POST['client'], $_POST['service'], $_POST['date']);
            else
                echo '<script>alert("'.array_shift($errors).'");</script>';
        }
        
        else {
            $exam = new Record($_POST['master'], $_POST['client'], $_POST['service'], $_POST['date']);
            $res = $db->getQueryResult("SELECT * from master where master_name='".$_SESSION['logged_master']."'");
            $master = mysqli_fetch_array($res)[0];
            if($_POST['master'] != $teacher && $_SESSION['logged_master'] != 'admin'){
                $errors[] = "Вы не можете добавлять запись другому мастеру!";
            }
            if(empty($errors))
                $exam->add();
            else
                echo '<script>alert("'.array_shift($errors).'");</script>';
        }
    }
    
    if(isset($_GET['delete'])){
        Record::delete($_GET['delete']);
    }

    
}
Record::displayForm();
Record::displayTable();
Inter::footer();
?>