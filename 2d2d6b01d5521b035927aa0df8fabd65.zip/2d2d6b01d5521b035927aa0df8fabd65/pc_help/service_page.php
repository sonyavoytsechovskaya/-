<?php
include_once (realpath('classes/Service.php'));
include_once (realpath('classes/Inter.php'));
Inter::head();
Service::displayForm();
Service::displayTable();
Inter::footer();
?>