<?php
include_once (realpath('classes/Client.php'));
include_once (realpath('classes/Inter.php'));
    Inter::head();
    Client::displayForm();
    Client::displayTable();
    Inter::footer();
?>