<?php
//класс для работы с интерфейсами
class Inter{
    public static function head(){
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin')
            include (realpath('../inter_elements/head.php'));
        else
            include (realpath('./inter_elements/head.php'));
    }
        public static function head2(){
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin')
            include (realpath('../inter_elements/head2.php'));
        else
            include (realpath('./inter_elements/head2.php'));
    }


    public static function menu(){
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin')
            include (realpath('../inter_elements/menu.php'));
        else
            include (realpath('./inter_elements/head.php'));
    }
    
    public static function loginForm(){
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin')
            include (realpath('../inter_elements/login_form.php'));
        else
            include (realpath('./inter_elements/login_form.php'));
    }
     public static function RecButton(){
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin')
            include (realpath('../inter_elements/rec_button.php'));
        else
            include (realpath('./inter_elements/rec_button.php'));
    }

    public static function footer(){
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin')
            include (realpath('../inter_elements/footer.php'));
        else
            include (realpath('./inter_elements/footer.php'));
    }
    
    public static function sort_link_th($title, $a, $b) { //функция сортировки
	    $sort = @$_GET['sort'];
    	if ($sort == $a) {
    		return '<a class="active" href="?sort=' . $b . '">' . $title . ' <i>▲</i></a>'; //ссылка, заголовок
    	} elseif ($sort == $b) {
    		return '<a class="active" href="?sort=' . $a . '">' . $title . ' <i>▼</i></a>';  
    	} else {
    		return '<a href="?sort=' . $a . '">' . $title . '</a>';  
    	}
    }
}
?>