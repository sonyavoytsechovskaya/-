<?php
include_once ('DB.php'); //ссылки
include_once ('Inter.php');

class Applications{
    public $number_client;
    public $services;
    public $date;
    
    public function __construct($number_client, $services, $date){ //инициализация полей таблицы
        $db = new DB;
        $this->number_client = $db->con->real_escape_string($number_client);
        $this->services = $db->con->real_escape_string($services);
        $this->date = $db->con->real_escape_string($date);
    }
    
    public function add(){ //функция добавления клиента в таблицу
        $db = new DB;
        $db->makeQuery("INSERT INTO `applications`(`number_client`, `services`, `date`) VALUES ('{$this->number_client}','{$this->services}', '{$this->date}')"); //добавляем услугу
    }
    
    public static function delete($id){ //функция удаления
        $db = new DB();
        $db->makeQuery("DELETE FROM `applications` WHERE id='{$id}'"); //удаляем по id
        echo mysqli_error($db->con);
    }
    
    public static function displayTable(){  //вывод таблицы
    //DESK - сортировка в порядке убывания, ASK - в порядке возрастания
        $sort_list = array(//массив с возможными вариантами сортировки по всём столбцам
    	    'id_asc'   => '`id`',
        	'id_desc'  => '`id` DESC',
        	'number_asc'   => '`number_client`',
        	'number_desc'  => '`number_client` DESC',
        	'services_asc'  => '`services`',
        	'services_desc' => '`services` DESC',
        	'date_asc'   => '`date`',
        	'date_desc'  => '`date` DESC'
        );
        $sort = @$_GET['sort']; //сортировка
        if (array_key_exists($sort, $sort_list)) { //Проверяет, присутствует ли в массиве указанный ключ или индекс
        	$sort_sql = $sort_list[$sort];//сортировка по умолчанию
        } else {
        	$sort_sql = reset($sort_list); //заново
        }
        
        $db = new DB;
        $sql = "";
        if(isset($_POST['search'])) //поиск
            $sql = Service::searchQuery()." ORDER BY $sort_sql";
        else
            $sql = "SELECT id, number_client, services, `date` FROM applications ORDER BY $sort_sql"; //выбираем всю таблицу и сортируем
        $res_data = $db->getQueryResult($sql); //результат
        
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если  зашли как админ
            echo '<link href="../css/table.css" rel="stylesheet">';
        else
            echo '<link href="css/table.css" rel="stylesheet">';
        echo '<table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                      //выводятся ссылки, срабатывает функция и сортируются
                    echo Inter::sort_link_th('№', 'id_asc', 'id_desc'); //формирует вывод ссылок исходя из значения переменной $_GET['sort'].
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Номер телефона', 'number_asc', 'number_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Услуга', 'services_asc', 'services_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Дата', 'date_asc', 'date_desc');
                    echo'</th>';
                    if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                        echo '<th></th>
                        <th></th>';
                    }
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) { //вывод таблицы
            while ($row = $res_data->fetch_assoc()) {
                    echo "<tr>
                        <td>".$row["id"]."</td>
                        <td>".$row["number_client"]."</td>
                        <td>".$row["services"]."</td>
                        <td>".$row["date"]."</td>";
                        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
                            echo "<td><a href='?delete={$row['id']}'>Удалить</a></td>
                                  <td><a href='?edit={$row['id']}'>Изменить</a></td>";
                    echo "</tr>";
            }
        }
        echo '</table>';

    }
    
    public static function searchQuery(){//поиск по всей таблице
        $querySearchList = "select service_id, service_name, service_price from service where ";
        //$queryAllList = "select service_id, service_name, service_price from Service";
        $query = $querySearchList;
        if(trim($_POST['service_name'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= "service_name LIKE N'%{$_POST['service_name']}%'";
        }
        
        if(trim($_POST['service_price'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " service_price LIKE N'%{$_POST['service_price']}%'";
        }
        
        return $query;
    }
}
?>