<?php  
session_start();
 //класс для работы с бд
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class DB{  
     public $con;  
     public $error;  
     public function __construct(){  
          $this->con = mysqli_connect("localhost", "u91128cj_6", "sAmogyg5", "u91128cj_6");  
          if(!$this->con){  
               echo 'Database Connection Error';
          }  
     }  
     
     public function getQueryResult($query){ //функция возвращает результат запроса
          $result = mysqli_query($this->con, $query);
          return $result;
     }
     
     public function makeQuery($query){ //выполнить запрос без результата
        mysqli_query($this->con, $query);
     }
     
     public function __destruct(){   //закрывает соедиение с бд
          $this->con->close();
     }  
 }  
 ?>  