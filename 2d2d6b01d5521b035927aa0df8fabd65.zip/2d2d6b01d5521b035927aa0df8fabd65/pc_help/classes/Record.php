<?php
require_once ('DB.php'); //ссылки

class Record {
    public $record_master_id;
    public $record_client_id;
    public $record_service_id;
    public $record_date;
    
    public function __construct($record_master_id, $record_client_id, $record_service_id, $record_date){ //инициализация полей таблицы
        $db = new DB;
        $this->record_master_id = $db->con->real_escape_string($record_master_id);
        $this->record_client_id = $db->con->real_escape_string($record_client_id);
        $this->record_service_id = $db->con->real_escape_string($record_service_id);
        $this->record_date = $db->con->real_escape_string($record_date);
    }
    
    public function add(){ //функция добавления записи в таблицу
        $db = new DB;
        $result = $db->getQueryResult("SELECT COUNT(*) FROM record WHERE record_master_id={$this->record_master_id} AND record_date='{$this->record_date}' AND record_client_id={$this->record_client_id} AND record_service_id={$this->record_service_id}"); //проверяем есть ли такая запись
        $recordCount = mysqli_fetch_array($result)[0];//из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
        if($recordCount > 0)//если больше 0 записей
            echo '<script language="javascript">alert("Такая запись уже есть!")</script>';//ошибка
        else
            $db->makeQuery("INSERT INTO `record`(`record_master_id`, `record_client_id`, `record_service_id`, `record_date`) VALUES ({$this->record_master_id}, {$this->record_client_id}, {$this->record_service_id}, '{$this->record_date}')"); //изменяем запись - вставляем в такие то поля такие то значения
    }
    
    public static function delete($id){ //функция удаления
        $db = new DB;
        $db->makeQuery("DELETE FROM `record` WHERE `record_id`={$id};"); //удаляем по id
    }
    
    public static function change($id, $record_master_id, $record_client_id, $record_service_id, $record_date){ //функция изменения
        $db = new DB;
        $result = $db->getQueryResult("SELECT * FROM record WHERE record_id={$id}");//проверяем есть ли такой id
        $record = mysqli_fetch_array($result);//подходят нашему запросу
        if($record['record_master_id'] != $record_master_id || $record['record_date'] != $record_date || $record['record_client_id'] != $record_client_id || $record['record_service_id'] != $record_service_id){//если такая запись уже была
            $result = $db->getQueryResult("SELECT COUNT(*) FROM record WHERE record_master_id={$record_master_id} AND record_date='{$record_date}' AND record_client_id={$record_client_id} AND record_service_id={$record_service_id}"); //изменяем данные записи
            $teacherCount = mysqli_fetch_array($result)[0];//из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
            if($teacherCount > 0) //если больше 0 записей
                echo '<script language="javascript">alert("Такая запись уже есть!")</script>'; //ошибка
            else
                $db->makeQuery("UPDATE `record` SET record_master_id={$record_master_id}, record_date='{$record_date}', record_client_id={$record_client_id}, record_service_id={$record_service_id} WHERE record_id={$id};"); //изменяем данные записи
        }
    }
    
    public static function displayTable(){//вывод таблицы
     //DESK - сортировка в порядке убывания, ASK - в порядке возрастания
        $sort_list = array( //массив с возможными вариантами сортировки по всём столбцам
    	    'record_id_asc'   => '`record_id`',
        	'record_id_desc'  => '`record_id` DESC',
        	'client_name_asc'   => '`client_name`',
        	'client_name_desc'  => '`client_name` DESC',
        	'master_name_asc'  => '`master_name`',
        	'master_name_desc' => '`master_name` DESC',
        	'record_date_asc'  => '`record_date`',
        	'record_date_desc' => '`record_date` DESC',
        	'service_name_asc'  => '`service_name`',
        	'service_name_desc' => '`service_name` DESC'
        );
        $sort = @$_GET['sort']; //сортировка
        if (array_key_exists($sort, $sort_list)) {  //Проверяет, присутствует ли в массиве указанный ключ или индекс
        	$sort_sql = $sort_list[$sort]; //сортировка по умолчанию
        } else {
        	$sort_sql = reset($sort_list); //заново
        }
        
        $db = new DB;
        $sql = "";
        if(isset($_POST['search'])){ //поиск
            $sql = Record::searchQuery()." ORDER BY $sort_sql"; 
        }
        else
        //
            $sql = "SELECT record_id, master_login, client_name, master_name, DATE_FORMAT(`record_date`, '%d-%m-%Y') record_date, service_name FROM record INNER JOIN client ON `record_client_id` = `client_id` INNER JOIN master ON `record_master_id` = `master_id` INNER JOIN service ON `record_service_id`=`service_id` ORDER BY $sort_sql";  //выбираем всю таблицу и сортируем
        $res_data = $db->getQueryResult($sql); //результат
        
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
            echo '<link href="../css/table.css" rel="stylesheet">';
        else
            echo '<link href="css/table.css" rel="stylesheet">';
        echo '<table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                      //выводятся ссылки, срабатывает функция и сортируются
                    echo Inter::sort_link_th('№', 'record_id_asc', 'record_id_desc');//формирует вывод ссылок исходя из значения переменной $_GET['sort'].
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Клиент', 'client_name_asc', 'client_name_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Мастер', 'master_name_asc', 'master_name_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Дата', 'record_date_asc', 'record_date_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Услуга', 'service_name_asc', 'service_name_desc');
                    echo'</th>';
                    if(isset($_SESSION['logged_master'])){ //если зашли как мастер
                        echo '<th></th>
                        <th></th>';
                    }
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) { //вывод таблицы
            while ($row = $res_data->fetch_assoc()) {
                echo "<tr>
                    <td>".$row["record_id"]."</td>
                    <td>".$row["client_name"]."</td>
                    <td>".$row["master_name"]."</td>
                    <td>".$row["record_date"]."</td>
                    <td>".$row["service_name"]."</td>";
                    if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == $row["master_login"] || isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                        echo "<td><a href='?delete={$row['record_id']}'>Удалить</a></td>
                        <td><a href='?edit={$row['record_id']}'>Изменить</a></td>";
                    }
                    
                    else if(isset($_SESSION['logged_master'])){
                        echo "<td> </td>
                              <td> </td>";
                    }
                echo "</tr>";
            }
        }
        echo '</table>';
    }
    
    public static function displayForm(){ //вывод формы
        $db = new DB;
        if(isset($_GET['edit'])){
            $product = mysqli_fetch_array($db->getQueryResult("SELECT * FROM record WHERE record_id={$_GET['edit']}"));//если нажимаем на редактирование выполняется этот запрос и в форму подгружаются данные
        }
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
            echo '<link href="../css/edit_form.css" rel="stylesheet">';
        else
            echo '<link href="css/edit_form.css" rel="stylesheet">';
        echo '<div class="edit-page">
            <div class="edit-form">
                    <form method="post" class="login-form">';
                        echo '<p>Клиент:</p>';
                        echo '<select name="client">';
                        $result = $db->getQueryResult("SELECT * FROM client");
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                    echo "<option";
                                    if($row['client_id'] == $product['record_client_id'])
                                        echo " selected='selected' ";
                                    echo " value=".$row["client_id"].">".$row["client_name"]."</option>";
                            }
                        } 
                        echo '</select>';
                        
                        echo '<p>Мастер:</p>';
                        echo '<select name="master">'; //выпадающий список
                        $result = $db->getQueryResult("SELECT * FROM master");
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                if($row['master_id'] != 1){
                                    echo "<option";
                                    if($row['master_id'] == $product['record_master_id'])
                                        echo " selected='selected' ";
                                    echo " value=".$row["master_id"].">".$row["master_name"]."</option>";
                                }
                            }
                        } 
                        echo '</select>';
                        
                        echo '<input type="date" name="date"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["record_date"].'"';
                        }
                        echo '>';
                        echo '<p>Услуга:</p>';
                        echo '<select name="service">'; //выпадающий список
                        $result = $db->getQueryResult("SELECT * FROM service");
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option";
                                if($row['service_id'] == $product['record_service_id'])
                                    echo " selected='selected' ";
                                echo " value=".$row["service_id"].">".$row["service_name"]."</option>";
                            }
                        } 
                        echo '</select>';
                        
                        if(isset($_SESSION['logged_master'])){
                            echo '<button type="submit" name="push">';
                                if(isset($_GET['edit']))
                                    echo "Изменить";
                                else
                                    echo "Добавить";
                            echo '</button>';
                        }
                        echo '<br/><br/>';
                        echo '<button type="submit" name="search">Поиск</button>';
                        if(isset($_GET['edit']) || isset($_POST['search']))
                            echo '<a href="?add=new">Очистить форму</a>';
                    echo'    
                    </form>
                </div>
        </div>
        ';
    }
    
    public static function searchQuery(){ //поиск по всей таблице
        $querySearchList = "select record_id, client_name, master_name, master_login, service_name, record_date from record, master, client, service where"; 
        //начальный запрос для поиска. В нем пока нет никаких условий.
        //С этим запросом сравнимаем формируемый запрос, который потом вернем.
        $queryAllList = "select record_id, client_name, master_name, master_login, service_name, record_date from record, master, client, service where `record_master_id` = `master_id` and `record_client_id` = `client_id` and `record_service_id`=`service_id`"; 
        //формируемый запрос складывается из querylllist и то, что дальше написано
        $query = $queryAllList;
        if(trim($_POST['master'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " record_master_id LIKE N'%{$_POST['master']}%'";
        }
        
        if(isset($_POST['client'])){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " record_client_id LIKE N'{$_POST['client']}'";
        }
        
        if(isset($_POST['service'])){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " record_service_id LIKE N'{$_POST['service']}'";
        }
        
        if(isset($_POST['date'])){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " record_date LIKE N'%{$_POST['date']}%'";
        }
        
        return $query;
    }
}
?>