<?php
include_once ('DB.php'); //ссылки
include_once ('Inter.php');
class Client{
    public $client_name;
    public $client_phone;
    public function __construct($client_name, $client_phone){ //инициализация полей таблицы
        $db = new DB;
        $this->client_name = $db->con->real_escape_string($client_name);
        $this->client_phone = $db->con->real_escape_string($client_phone);
    }
    
    public function add(){ //функция добавления клиента в таблицу
        $db = new DB;
        $result = $db->getQueryResult("SELECT COUNT(*) FROM client WHERE client_name='{$this->client_name}' AND client_phone='{$this->client_phone}'"); //проверяем, есть ли такой клиент
        $clientCount = mysqli_fetch_array($result)[0]; //из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
        if($clientCount > 0) //если больше 0 клиента
            echo '<script language="javascript">alert("Такой клиент уже есть!");</script>'; //ошибка
        else
            $db->makeQuery("INSERT INTO `client`(`client_name`, `client_phone`) VALUES ('{$this->client_name}', '{$this->client_phone}')"); //добавляем клиента
    }
    
    public static function delete($id){ //функция удаления
        $db = new DB();
        $db->makeQuery("DELETE FROM `client` WHERE client_id={$id};"); //удаляем по id
    }
    
    public static function change($id, $client_name, $client_phone){ //функция изменения
        $db = new DB;
        $result = $db->getQueryResult("SELECT * FROM client WHERE client_id={$id}"); //проверяем есть ли такой id
        $client = mysqli_fetch_array($result); //подходят нашему запросу
        if($client['client_phone'] == $client_phone) //если номер такой же как был
            $db->makeQuery("UPDATE `client` SET `client_name`='{$client_name}', `client_phone`='{$client_phone}' WHERE client_id={$id}"); //изменяем данные клиента
        else{ //если есть с таким номером
            $result = $db->getQueryResult("SELECT COUNT(*) FROM client WHERE client_phone='{$client_phone}'"); //проверяем, есть ли такой номер
            $clientCount = mysqli_fetch_array($result)[0]; //из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
            if($clientCount > 0) //если больше 0 клиента
                echo '<script language="javascript">alert("Такой клиент уже есть!");</script>'; //ошибка
            else //иначе
                $db->makeQuery("UPDATE `client` SET `client_name`='{$client_name}', `client_phone`='{$client_phone}' WHERE client_id={$id}"); //изменяем данные клиента
        }
    }
    
    public static function displayTable(){ //вывод таблицы
    //DESK - сортировка в порядке убывания, ASK - в порядке возрастания
        $sort_list = array( //массив с возможными вариантами сортировки по всём столбцам
    	    'client_id_asc'   => '`client_id`',
        	'client_id_desc'  => '`client_id` DESC',
        	'client_name_asc'  => '`client_name`',
        	'client_name_desc' => '`client_name` DESC',
        	'client_phone_asc'  => '`client_phone`',
        	'client_phone_desc' => '`client_phone` DESC'
        );
        $sort = @$_GET['sort']; //сортировка
        if (array_key_exists($sort, $sort_list)) { //Проверяет, присутствует ли в массиве указанный ключ или индекс
        	$sort_sql = $sort_list[$sort]; //сортировка по умолчанию
        } else {
        	$sort_sql = reset($sort_list); //заново
        }
        
        $db = new DB;
        if(isset($_POST['search'])){ //поиск
            $sql = Client::searchQuery()." ORDER BY $sort_sql";
            //echo Client::searchQuery();
        }
        else //иначе
            $sql = "SELECT client_id, client_name, client_phone FROM client ORDER BY $sort_sql"; //выбираем всю таблицу и сортируем
        $res_data = $db->getQueryResult($sql); //результат
        
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
            echo '<link href="../css/table.css" rel="stylesheet">';
        else
            echo '<link href="css/table.css" rel="stylesheet">';
        echo '
        <table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                      //выводятся ссылки, срабатывает функция и сортируются
                    echo Inter::sort_link_th('№', 'client_id_asc', 'client_id_desc');   //формирует вывод ссылок исходя из значения переменной $_GET['sort'].
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('ФИО', 'client_name_asc', 'client_name_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Телефон', 'client_phone_asc', 'client_phone_desc');
                    echo'</th>';
                    if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                        echo '<th></th>
                        <th></th>';
                    }
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) { //вывод таблицы
            while ($row = $res_data->fetch_assoc()) {
                echo "<tr>
                    <td>".$row["client_id"]."</td>
                    <td>".$row["client_name"]."</td>
                    <td>".$row["client_phone"]."</td>";
                    if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
                        echo "<td><a href='?delete={$row['client_id']}'>Удалить</a></td>
                              <td><a href='?edit={$row['client_id']}'>Изменить</a></td>";
                    echo "</tr>";
            }
        }
        echo '</table>';
    }
    
    public static function displayForm(){ //вывод формы
        $db = new DB;
        if(isset($_GET['edit'])){
            $product = mysqli_fetch_array($db->getQueryResult("SELECT * FROM client WHERE client_id={$_GET['edit']}")); //если нажимаем на редактирование выполняется этот запрос и в форму подгружаются данные
        }
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
            echo '<link href="../css/edit_form.css" rel="stylesheet">';
        else
            echo '<link href="css/edit_form.css" rel="stylesheet">';
        echo '<div class="edit-page">
            <div class="edit-form">
                    <form method="post" class="login-form">
                    <p>База клиентов</p>
                        <input type="text" placeholder="ФИО клиента" name="client_name"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["client_name"].'"';
                        }
                        echo '>';
                        echo '<input type="text" placeholder="Телефон: 89211234567"  name="client_phone"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["client_phone"].'"';
                        }
                        echo '>';
                        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                            echo '<button type="submit" name="push">';
                            
                            if(isset($_GET['edit']))
                                echo "Изменить";
                            else
                                echo "Добавить";
                        }
                            
                        echo '</button>';
                        echo '<br/><br/>';
                        echo '<button type="submit" name="search">Поиск</button>';
                        if(isset($_GET['edit']) || isset($_POST['search']))
                            echo '<a href="?add=new">Очистить форму</a>';
                    echo'    
                    </form>
                </div>
        </div>
        ';
    }
    
    public static function searchQuery(){ //поиск по всей таблице
        $querySearchList = "select client_id, client_name, client_phone from client where ";
        //$queryAllList = "select client_id, client_name, client_phone from client";
        $query = $querySearchList;
        if(trim($_POST['client_name'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " client_name LIKE N'%{$_POST['client_name']}%'";
        }
        
        if(trim($_POST['client_phone'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " client_phone LIKE N'%{$_POST['client_phone']}%'";
        }
        
        return $query;
    }
}
?>