<?php
include_once ('DB.php'); //ссылки
include_once ('Inter.php');

class Service{
    public $service_name;
    public $service_price;
    
    public function __construct($service_name, $service_price){ //инициализация полей таблицы
        $db = new DB;
        $this->service_name = $db->con->real_escape_string($service_name);
        $this->service_price = $db->con->real_escape_string($service_price);
    }
    
    public function add(){ //функция добавления клиента в таблицу
        $db = new DB;
        $result = $db->getQueryResult("SELECT COUNT(*) FROM service WHERE service_name='{$this->service_price}'"); //проверяем есть ли такая услуга
        $serviceCount = mysqli_fetch_array($result)[0];//из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
        if($serviceCount > 0) //если больше 0 записей
            echo '<script language="javascript">alert("Такая услуга уже есть!")</script>'; //ошибка
        else
            $db->makeQuery("INSERT INTO `service`(`service_name`, `service_price`) VALUES ('{$this->service_name}','{$this->service_price}')"); //добавляем услугу
    }
    
    public static function delete($id){ //функция удаления
        $db = new DB();
        $db->makeQuery("DELETE FROM `service` WHERE service_id={$id}"); //удаляем по id
    }
    
    public static function change($id, $service_name, $service_price){ //функция изменения
        $db = new DB;
        $result = $db->getQueryResult("SELECT * FROM service WHERE service_id={$id}");//проверяем есть ли такой id
        $service = mysqli_fetch_array($result);//подходят нашему запросу
        
        if($service['service_name'] == $service_name){  //если такая услуга уже была
            $db->makeQuery("UPDATE Service SET service_name='{$db->con->real_escape_string($service_name)}', service_price={$db->con->real_escape_string($service_price)} WHERE service_id={$db->con->real_escape_string($id)}"); //изменяем данные услуги
        }
        
        else{
            $result = $db->getQueryResult("SELECT COUNT(*) FROM service WHERE service_name='{$service_name}'"); //проверяем, есть ли такая услуга
            $serviceCount = mysqli_fetch_array($result)[0];//из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
            if($serviceCount > 0)//если больше 0 клиента
                echo '<script language="javascript">alert("Такая услуга уже есть!")</script>'; //ошибка
            else{ //иначе
                $db->makeQuery("UPDATE service SET service_name='{$db->con->real_escape_string($service_name)}', service_price={$db->con->real_escape_string($service_price)} WHERE service_id={$db->con->real_escape_string($id)}"); //изменяем данные услуги
            }
        }
    }
    
    public static function displayTable(){  //вывод таблицы
    //DESK - сортировка в порядке убывания, ASK - в порядке возрастания
        $sort_list = array(//массив с возможными вариантами сортировки по всём столбцам
    	    'service_id_asc'   => '`service_id`',
        	'service_id_desc'  => '`service_id` DESC',
        	'service_name_asc'  => '`service_name`',
        	'service_name_desc' => '`service_name` DESC',
        	'service_price_asc'   => '`service_price`',
        	'service_price_desc'  => '`service_price` DESC'
        );
        $sort = @$_GET['sort']; //сортировка
        if (array_key_exists($sort, $sort_list)) { //Проверяет, присутствует ли в массиве указанный ключ или индекс
        	$sort_sql = $sort_list[$sort];//сортировка по умолчанию
        } else {
        	$sort_sql = reset($sort_list); //заново
        }
        
        $db = new DB;
        $sql = "";
        if(isset($_POST['search'])) //поиск
            $sql = Service::searchQuery()." ORDER BY $sort_sql";
        else
            $sql = "SELECT service_id, service_name, service_price FROM service ORDER BY $sort_sql"; //выбираем всю таблицу и сортируем
        $res_data = $db->getQueryResult($sql); //результат
        
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если  зашли как админ
            echo '<link href="../css/table.css" rel="stylesheet">';
        else
            echo '<link href="css/table.css" rel="stylesheet">';
        echo '<table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                      //выводятся ссылки, срабатывает функция и сортируются
                    echo Inter::sort_link_th('№', 'service_id_asc', 'service_id_desc'); //формирует вывод ссылок исходя из значения переменной $_GET['sort'].
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Услуга', 'service_name_asc', 'service_name_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Цена', 'service_price_asc', 'service_price_desc');
                    echo'</th>';
                    if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                        echo '<th></th>
                        <th></th>';
                    }
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) { //вывод таблицы
            while ($row = $res_data->fetch_assoc()) {
                    echo "<tr>
                        <td>".$row["service_id"]."</td>
                        <td>".$row["service_name"]."</td>
                        <td>".$row["service_price"]."</td>";
                        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
                            echo "<td><a href='?delete={$row['service_id']}'>Удалить</a></td>
                                  <td><a href='?edit={$row['service_id']}'>Изменить</a></td>";
                    echo "</tr>";
            }
        }
        echo '</table>';

    }
    
    public static function displayForm(){ //вывод формы
        $db = new DB;
        if(isset($_GET['edit'])){
            $product = mysqli_fetch_array($db->getQueryResult("SELECT * FROM service WHERE service_id={$_GET['edit']}"));//если нажимаем на редактирование выполняется этот запрос и в форму подгружаются данные
        }
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ 
            echo '<link href="../css/edit_form.css" rel="stylesheet">';
        else
            echo '<link href="css/edit_form.css" rel="stylesheet">';
        echo '<div class="edit-page">
            <div class="edit-form">
             <p>Наши услуги</p>
                    <form method="post" class="login-form">
                        <input type="text" placeholder="Услуга" name="service_name"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["service_name"].'"';
                        }
                        echo '>';
                        
                        echo '<input type="text" placeholder="Цена" name="service_price"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["service_price"].'"';
                        }
                        echo'>';
                        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                            echo '<button type="submit" name="push">';
                            
                            if(isset($_GET['edit']))
                                echo "Изменить";
                            else
                                echo "Добавить";
                            echo '</button>';
                        }
                            
                        
                        echo '<br/><br/>';
                        echo '<button type="submit" name="search">Поиск</button>';
                        
                        if(isset($_GET['edit']) || isset($_POST['search']))
                            echo '<a href="?add=new">Очистить форму</a>';
                    echo'    
                    </form>
                </div>
        </div>
        ';
    }
    
    public static function searchQuery(){//поиск по всей таблице
        $querySearchList = "select service_id, service_name, service_price from service where ";
        //$queryAllList = "select service_id, service_name, service_price from Service";
        $query = $querySearchList;
        if(trim($_POST['service_name'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= "service_name LIKE N'%{$_POST['service_name']}%'";
        }
        
        if(trim($_POST['service_price'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " service_price LIKE N'%{$_POST['service_price']}%'";
        }
        
        return $query;
    }
}
?>