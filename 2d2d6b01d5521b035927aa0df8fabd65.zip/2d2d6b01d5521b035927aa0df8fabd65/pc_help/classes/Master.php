<?php
include_once ('DB.php'); //ссылки
include_once ('Inter.php');

class Master{
    public $master_name;
    public $master_login;
    public $master_password;
    
    public function __construct($master_name, $master_login, $master_password){//инициализация полей таблицы
        $db = new DB;
        $this->master_name = $db->con->real_escape_string($master_name);
        $this->master_login = $db->con->real_escape_string($master_login);
        $this->master_password = $db->con->real_escape_string($master_password);
    }
    
    public function add(){ //функция добавления мастера в таблицу
        $db = new DB;
        $result = $db->getQueryResult("SELECT COUNT(*) FROM master WHERE master_login='{$this->master_login}'"); //проверяем, есть ли такой мастер
        $masterCount = mysqli_fetch_array($result)[0];  //из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
        if($masterCount > 0) //если больше 0 клиента
            echo '<script language="javascript">alert("Мастер с таким логином уже есть!")</script>'; //ошибка
        else
            $db->makeQuery("INSERT INTO `master`(`master_name`, `master_login`, `master_password`) VALUES ('{$this->master_name}','{$this->master_login}', '".password_hash($this->master_password, PASSWORD_DEFAULT)."')"); //добавляем мастера и хэширование пароля
    }
    
    public static function delete($id){ //функиция удаления
        $db = new DB();
        $db->makeQuery("DELETE FROM `master` WHERE master_id={$id}"); //удаляем по id
    }
    
    public static function change($id, $master_name, $master_login, $master_password){ //функция изменения
        $db = new DB;
        $result = $db->getQueryResult("SELECT * FROM master WHERE master_id={$id}"); //проверяем есть ли такой id
        $master = mysqli_fetch_array($result); //подходят нашему запросу
        
        if($master['master_login'] == $master_login){ //если зашли как мастер
            $dop = '';
            if (trim($master_password) != ''){ //пароль мастера не равен пустому
                $pass = $db->con->real_escape_string($master_password); //пароль передается
                $dop = ', master_password="'.password_hash($pass, PASSWORD_DEFAULT).'"'; //пароль хэшируется
            }
            $db->makeQuery("UPDATE master SET master_name='{$db->con->real_escape_string($master_name)}', master_login='{$db->con->real_escape_string($master_login)}'".$dop." WHERE master_id={$db->con->real_escape_string($id)}"); //изменяем данные мастера
        }
        
        else{ //иначе
            $result = $db->getQueryResult("SELECT COUNT(*) FROM master WHERE master_login='{$master_login}'"); //проверяем, есть ли мастер с таким логином
            $masterCount = mysqli_fetch_array($result)[0]; //из массива результата вытаскиваем первый элемент. В нём количество записей, которые подходят по нашему запросу
            if($masterCount > 0) //если больше 0 мастеров
                echo '<script language="javascript">alert("Мастер с таким логином уже есть!")</script>'; //выводим ошибку
            else{ //иначе 
                $dop = '';
                if (trim($master_password) != ''){ //если пароль мастера не пустой
                    $pass = $db->con->real_escape_string($master_password); //пароль передается
                    $dop = ', master_password="'.password_hash($pass, PASSWORD_DEFAULT).'"';  //пароль хэшируется
                }
                $db->makeQuery("UPDATE master SET master_name='{$db->con->real_escape_string($master_name)}', master_login='{$db->con->real_escape_string($master_login)}'".$dop." WHERE master_id={$db->con->real_escape_string($id)}"); //изменяем данные мастера
            }
        }
    }
    
    public static function displayTable(){ //вывод таблицы
     //DESK - сортировка в порядке убывания, ASK - в порядке возрастания
        $sort_list = array( //массив с возможными вариантами сортировки по всём столбцам
    	    'master_id_asc'   => '`master_id`',
        	'master_id_desc'  => '`master_id` DESC',
        	'master_name_asc'  => '`master_name`',
        	'master_name_desc' => '`master_name` DESC',
        	'master_login_asc'   => '`master_login`',
        	'master_login_desc'  => '`master_login` DESC'
        );
        $sort = @$_GET['sort']; //сортировка
        if (array_key_exists($sort, $sort_list)) {  //Проверяет, присутствует ли в массиве указанный ключ или индекс
        	$sort_sql = $sort_list[$sort];//сортируем по умолчанию
        } else {
        	$sort_sql = reset($sort_list);//заново
        }
        
        $db = new DB;
        $sql = "";
        if(isset($_POST['search'])) //поиск
            $sql = Master::searchQuery()." ORDER BY $sort_sql"; //срабатывает сортировка
        else
            $sql = "SELECT master_id, master_name, master_login FROM master ORDER BY $sort_sql";//выбираем всю таблицу и сортируем
        $res_data = $db->getQueryResult($sql);
        
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
            echo '<link href="../css/table.css" rel="stylesheet">';
        else
            echo '<link href="css/table.css" rel="stylesheet">';
        echo '<table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                      //выводятся ссылки, срабатывает функция и сортируются
                    echo Inter::sort_link_th('№', 'master_id_asc', 'master_id_desc');//формирует вывод ссылок исходя из значения переменной $_GET['sort'].
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('ФИО', 'master_name_asc', 'master_name_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Логин', 'master_login_asc', 'master_login_desc');
                    echo'</th>';
                    if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                        echo '<th></th>
                        <th></th>';
                    }
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) { //вывод таблицы
            while ($row = $res_data->fetch_assoc()) {
                if($row["master_login"] != 'admin'){
                    echo "<tr>
                        <td>".$row["master_id"]."</td>
                        <td>".$row["master_name"]."</td>
                        <td>".$row["master_login"]."</td>";
                        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
                            echo "<td><a href='?delete={$row['master_id']}'>Удалить</a></td>
                                  <td><a href='?edit={$row['master_id']}'>Изменить</a></td>";
                    echo "</tr>";
                }
            }
        }
        echo '</table>';

    }
    
    public static function displayForm(){ //вывод формы
        $db = new DB;
        if(isset($_GET['edit'])){
            $product = mysqli_fetch_array($db->getQueryResult("SELECT * FROM master WHERE master_id={$_GET['edit']}"));//если нажимаем на редактирование выполняется этот запрос и в форму подгружаются данные
        }
        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin') //если зашли как админ
            echo '<link href="../css/edit_form.css" rel="stylesheet">';
        else
            echo '<link href="css/edit_form.css" rel="stylesheet">';
        echo '<div class="edit-page">
            <div class="edit-form">
             <p>База мастеров</p>
                    <form method="post" class="login-form">
                        <input type="text" placeholder="ФИО" name="master_name"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["master_name"].'"';
                        }
                        echo '>';
                        
                        echo '<input type="text" placeholder="Логин" name="master_login"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["master_login"].'"';
                        }
                        echo'>';
                        echo '<input type="password" placeholder="Пароль" name="master_password">';
                        if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){ //если зашли как админ
                            echo '<button type="submit" name="push">';
                            
                            if(isset($_GET['edit']))
                                echo "Изменить";
                            else
                                echo "Добавить";
                        }
                            
                        echo '</button>';
                        echo '<br/><br/>';
                        echo '<button type="submit" name="search">Поиск</button>';
                        
                        if(isset($_GET['edit']) || isset($_POST['search']))
                            echo '<a href="?add=new">Очистить форму</a>';
                    echo'    
                    </form>
                </div>
        </div>
        ';
    }
    
    public static function searchQuery(){ //поиск по всей таблице
        $querySearchList = "select master_id, master_name, master_login from master where ";
        //$queryAllList = "select master_id, master_name, master_login from master";
        $query = $querySearchList;
        if(trim($_POST['master_name'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= "master_name LIKE N'%{$_POST['master_name']}%'";
        }
        
        if(trim($_POST['master_login'])!=''){
            if ($query != $querySearchList)
                $query .= " AND ";
            $query .= " master_login LIKE N'%{$_POST['master_login']}%'";
        }
        
        return $query;
    }
}
?>