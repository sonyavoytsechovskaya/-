<?php
include_once (realpath('classes/Master.php'));
include_once (realpath('classes/Inter.php'));

Inter::head();
Master::displayForm();
Master::displayTable();
Inter::footer();
?>