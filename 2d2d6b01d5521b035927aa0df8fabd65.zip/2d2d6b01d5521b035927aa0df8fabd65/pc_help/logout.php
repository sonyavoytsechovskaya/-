<?php
require_once 'classes/DB.php';

if($_SESSION['logged_master'] == 'admin'){
    unset($_SESSION['logged_master']);
    echo "<script>
        location.replace('./index.php');
        </script>";
}

else{
    unset($_SESSION['logged_master']);
    echo "<script>
        location.replace('index.php');
        </script>";
}
?>