<?php
require_once 'classes/DB.php';
require_once 'classes/Inter.php';
require_once 'classes/Master.php';
require_once 'classes/Applications.php';

$data = $_POST;
$db = new DB;

if(isset($_SESSION['logged_master']) && $_SESSION['logged_master'] == 'admin'){
    echo "<script>location.replace('admin/index.php');</script>";
}

if (isset($data['do_login'])) {
	
    $query = "SELECT * FROM master WHERE master_login='{$data['master_login']}'";
    $result = mysqli_query($db->con, $query);
    
    if($result){
        $row = mysqli_fetch_row($result);
        $master = new Master($row[1], $row[2], $row[3]);
        if(password_verify($data['master_password'], $master->master_password))  
        {
            $_SESSION["logged_master"] = $master->master_login;  
            
            if($_SESSION["logged_master"] == 'admin')
                echo "<script>
                        location.replace('admin/index.php');
                      </script>";
            else{
                echo $_SESSION["logged_master"];
        
            }
        }  
        else  
        {  
            $message = $db->error;  
            echo $message;
        }
    }
}

if(isset($data['do_record'])){
    $record = new Applications($data['number_client'], $data['services'], $data['date']);
    $record->add();
}

 if(isset($_GET['delete'])){
    Applications::delete($_GET['delete']); 
 }

if(!isset($_SESSION['logged_master'])){
    Inter::head2();
    echo '<h1 style="text-align: center; font-family: Palatino Linotype;font-size: 30pt;text-transform:uppercase;">Ремонт компьютеров в Санкт-Петербурге</h1>
';
    Inter::loginForm();
    Inter::RecButton();

}

else{
    
    Inter::head();
    echo '
    <h1 style="text-align: center; font-family: Palatino Linotype;font-size: 30pt;text-transform:uppercase;">Ремонт компьютеров в Санкт-Петербурге</h1>
<h1 style="color:red;margin-top:130px;text-align: center; font-family: Palatino Linotype;font-size: 30pt;text-transform:uppercase;">Добро пожаловать, мастер.</h1>';
    echo "Вы вошли в систему как ".$_SESSION["logged_master"];
    Applications::displayTable();
}
Inter::footer();
?>